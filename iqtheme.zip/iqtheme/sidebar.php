<div id="sidebar">
    <ul class="sidebar">
        <?php dynamic_sidebar( 'blog-sidebar' ); ?>
    </ul>
</div>