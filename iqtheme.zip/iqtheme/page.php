<?php get_header();  ?>
    <div id="content">
        <?php get_template_part('loop', 'page');
              get_template_part('loop', 'section'); ?>
    </div>

<?php get_footer(); ?>