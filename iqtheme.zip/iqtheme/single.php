<?php get_header(); ?>
    <div id="content" class="bloop">
        <?php get_template_part('loop', 'blog');
              global $post;
              $nosidebar = get_post_meta($post->ID,'has_sidebar', true);
              if($nosidebar !== 'yes')get_template_part('sidebar', 'blog'); ?>
        <?php
        if ( comments_open() || get_comments_number() ) {
            comments_template();
        } ?>
    </div>
<?php get_footer(); ?>