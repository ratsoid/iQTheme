<?php get_header(); ?>
    <div id="content" class="bloop">
        <?php get_template_part('loop', 'blog'); ?>
        <?php get_template_part('sidebar', 'blog'); ?>
    </div>
<?php get_footer(); ?>